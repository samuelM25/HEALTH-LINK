function previewImage(event){
     
}