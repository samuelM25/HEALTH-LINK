
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>registration</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
   
    
    <div id=card>
    <form action="registration process.php" method="POST" id="form-container">
        <h1 id="heading">SIGNUP</h1>
        <label >username</label>
        <input type="username" name="username" placeholder="Enter username" required>

        <label >Email</label>
        <input type="email"  name="email" placeholder="Enter email" required>

        <label> Password</label>
        <input type="password" name="password" placeholder="Enter password" required>

        <label >Telephone</label>
        <input type="telephone" name="telephone" placeholder="Enter Telephone">

        <label >country</label>
        <input type="country" name="country" placeholder="Enter Country">
        <button type="submit">SIGNUP</button>
    </form>
    </div>
   
</body>
</html>