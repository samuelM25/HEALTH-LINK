<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php require_once("common.php")?>
    <div class="upload-card">
       <h2>UPLOAD IMAGE</h2>
        <form action="upload process.php" method="POST" enctype="multipart/form-data">

           <label >image Title</label>
           <input type="text" name="title" placeholder="image title" required>

           <label >Select image</label>
           <input type="file" name="image" accept="image/*" required>
        
           <button type="submit">UPLOAD</button>
        </form>
    </div>
</body>
</html>