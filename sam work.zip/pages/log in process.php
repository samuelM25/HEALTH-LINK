<?php
session_start();
require_once("common.php");//connecting to database

$errors =[];

if($_SERVER["REQUEST_METHOD"]=="POST"){ //run code when form is submitted

    //get information from the form
    $username =$_POST["username"]??"";
    $password = trim($_POST["password"]??"");
    $email = $_POST["email"]??"";

    //validation
    if(empty($username)) $errors[]="username required";
    if(empty($password)) $errors[]="password required";
    if(empty($email)) $errors[]="email required";

    if(!empty($errors)){
        foreach($errors as $err){
            echo"<p>$err<p>";
            exit;
        }
    }

    //selecting info from users table  that have same name entered
    $sql="SELECT * FROM users WHERE username='$username'";
    $result = mysqli_query($conn,$sql);

    //checking if user exists
    $user = mysqli_fetch_assoc($result);
    
    if(!$user){
        echo"user not found";
        exit;
    }
    //checking password
    if(!password_verify($password,$user['password'])) {
        echo"wrong password";
        exit;
    }
    //create session login user
    $_SESSION["user_id"] = $user["id"];
    $_SESSION["username"] = $username;

    //if password is correct  redirect to index.php
    header("location: index.php");
    exit();

      
    
      
   
    
}
?>