<?php require_once("common.php"); 
//checking for id
if(!isset($_GET["id"])){
    echo"image not found in database";
    exit; 
}
$id =$_GET["id"];//getting id
//get id from database
$sql = "SELECT image FROM images WHERE id = $id";
$result = mysqli_query($conn,$sql);


//get row from the database
if(!$row = mysqli_fetch_assoc($result)){
  echo"no id procided";
  exit;
}
$image_name =$row["image"];
    
//file path of where the file is located
$file_path = "images/".$image_names;

//if it exists delete it
    if (!empty($image_name) && file_exists($file_path)){
    unlink($file_path);
}
    
//delete from the database
$delete_sql ="DELETE FROM images WHERE id = $id";
mysqli_query($conn,$delete_sql);

//redirect to the index.php page
header("location: index.php");
exit();




      

?>


