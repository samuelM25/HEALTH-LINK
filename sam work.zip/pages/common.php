 <link rel="stylesheet" href="styles.css">
<div class ="navbar">
    <div class="logo">MY GALLERY</div>

    <ul class="nav-links">
       <a href="index.php">HOME</a>
       <a href="login.php">LOGIN</a>
       <a href="register.php">SIGNUP</a>
       <a href="upload.php">UPLOAD IMAGE</a>
    </ul>

    <div class="search-container">
        <form action="search.php" method="GET">
            <input type="text" name="query" placeholder="search images">
            <button type="submit">search</button>
        </form>
    </div>
</div>




<?php
$host = "localhost";
$user ="root";
$pass ="";
$db ="gallery_db"; 

$conn =  mysqli_connect("localhost","root","","gallery_db");

if($conn->connect_error){
    die("connect failed:" .$conn->connect_error);
}

?>

