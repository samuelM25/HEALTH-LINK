<?php
require_once("common.php"); //connecting to the database

//checking if search is set
$search = $_GET['query']??"";

//this is a base query
$search = "SELECT * FROM images";

//search input  with serach filters
if(!empty($search)){
   $sql ="SELECT * FROM images WHERE image LIKE '%search%'";
  $result = mysqli_query($conn,$sql); //runs the query
}

if(mysqli_num_rows($result)>0){ //any results returned
    while($row = mysqli_fetch_assoc($result)){ //going through the database
        $image = $row['image'];
        echo"<img src='images/$image' width='200'>";
    }
}else{
    echo"no images found";
}
?>