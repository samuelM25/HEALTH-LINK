
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>log in</title>
    <link rel="stylesheet" href="styles.css">
</head>
 <body>
    

    <div id="card-2">
        <h1 id="heading"> LOGIN</h1>
        <form action="log in process.php" method="POST" id="form-container">
          <label > username</label>
          <input type="username" name="username" required placeholder="Enter username" >

          <label >Email</label>
          <input type="email" name="email" required placeholder="Enter email">

          <label > Password</label>
          <input type="password" name="password" required placeholder="Enter password">
          <button type="submit">Login</button>

          <p>Don't have an account? <a href="register.php">Signup</a></p>
       </form>
    </div>
  
    
</body>
</html>