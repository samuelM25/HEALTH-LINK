<?php

require_once("common.php");

$conn = new mysqli("localhost","root","","gallery_db");

if($_SERVER["REQUEST_METHOD"] =='POST'){

   $title = $_POST['title']??'';
   

    if(isset($_FILES['image']) && $_FILES['image']['error']==0){
 
      //get information about the file your uploading
      $temp_name = $_FILES["image"]["tmp_name"]; //temp file location
      $image_name = $_FILES["image"]["name"]; // getting file name
      $folder ="images/".$image_name;// destination folder
      
      echo $folder;


       //move file to images folder
       if(move_uploaded_file($temp_name,$folder)){
 
           //insert the information into the database
           $sql = "INSERT INTO images (title,image) VALUES ('$title','$image_name')";
            if($conn->query($sql) ){
                header("location: index.php");
                exit();
            
            }else{
                 echo"database error:" .$conn->error;
            }
    }else{
        echo"failed to move uploaded file";
    }
        }else{
            echo"No image uploaded or upload error";
        }
  
}
?>