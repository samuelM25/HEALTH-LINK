<?php
session_start();
require_once("common.php");

$errors=[];// initialize array

if($_SERVER["REQUEST_METHOD"] == "POST"){

  //get form data safely
   $username = isset($_POST["username"])? $_POST["username"]:"";
   $email = isset($_POST["email"])? $_POST["email"]:"";
   $password = isset($_POST["password"]) ?$_POST["password"]:"";
   $telephone = isset($_POST["telephone"])?$_POST["telephone"]:"";
   $country =isset($_POST["country"])?$_POST["country"]:"";

   //validation
  if(empty($username)){
     $errors[]="username is required";
   }
    if(empty($email)) {
     $errors[]="Email is required";
    }
    if(empty($password)){
      $errors[]="Password is required";
    }
    if(empty($telephone)){
     $errors[]="Telephone is require";
    }
    if(empty($country)){
     $errors[]="Country is required";
    }

   //check if username exists in our db
   $sql="SELECT * FROM users WHERE email='$email'";
   $result = mysqli_query($conn,$sql);

   if($result->num_rows > 0){
       echo" email is already registered";
     exit();
    }
   //if user dosent exist insert there data into the db
  if(!empty($errors)){
      foreach($errors as $err){
         echo"<p> $err</p>"; 
          exit;
        }
    }
    $hashed = password_hash($password,PASSWORD_DEFAULT);
    $sql =("INSERT INTO users (username,email,password) VALUES ('$username','$email','$hashed')");

    if($conn ->query($sql)){
        $_SESSION["user_id"] = $conn -> insert_id;
        $_SESSION["username"] = $username;

        header("location: index.php");
        exit();
    }
    

}

?>