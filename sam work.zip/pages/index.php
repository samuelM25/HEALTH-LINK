<?php 
session_start();
if(!isset($_SESSION["user_id"])){
   header("location: login.php");
}

require_once("common.php"); 

//selecting or grtting  thr data from the database
$sql= "SELECT * FROM images";
$result =$conn->query($sql);



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOME PAGE</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
   <div class="gallery2">
        <?php 
           if($result->num_rows >0){
               while($row = $result->fetch_assoc()){
                  $image_name = $row['image'];
                  $title = $row['title'];
            
         ?>
            <div class="card3" onchange="">
              <img  id="preview "src="images/<?php echo $image_name;?>" class="" width="200">
               <ul class="delete"><a href="delete.php?id=<?php echo $row ['id']; ?>" class="delete-btn">Delete</a></ul>
              <i class="fa-solid fa-trash"></i>
            </div>
            <?php
              }
              }else{
              echo"no images uploaded yet";
              }
            ?>
   </div>
</body >
</html>